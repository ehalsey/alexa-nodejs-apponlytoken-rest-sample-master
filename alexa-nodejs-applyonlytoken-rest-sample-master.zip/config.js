/*
 * Copyright (c) Microsoft All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

// Application credentials from the Azure Management Portal.
module.exports = {
  clientId: 'c48aecef-f346-413c-8c76-835aa6c084ee',
  clientSecret: '97YueAEGyzGlruCGD41cKm2lC3yP+ZT5glz/QprNJQ0=',
  tokenEndpoint: 'https://login.windows.net/f8ac75ce-d250-407e-b8cb-e05f5b4cd913/oauth2/token'
};
