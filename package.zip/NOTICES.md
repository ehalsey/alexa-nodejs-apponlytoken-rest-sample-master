This project uses the following third-party components.

* [Node.js](https://nodejs.org/), Copyright (c) by Joyent, Inc. and other Node contributors, is available under the [Node.js license](https://raw.githubusercontent.com/nodejs/node/master/LICENSE).
* [Chalk](https://github.com/chalk/chalk), Copyright (c) by Sindre Sorhus, is available under [The MIT License](https://raw.githubusercontent.com/chalk/chalk/master/license).
* [Q](https://github.com/kriskowal/q), Copyright (c) by Kristopher Michael Kowal, is available under [The MIT License](https://raw.githubusercontent.com/kriskowal/q/v1/LICENSE).
* [Request](https://github.com/request/request), Copyright (c) by Simeon Velichkov, is available under the [Apache License 2.0](https://raw.githubusercontent.com/request/request/master/LICENSE).
