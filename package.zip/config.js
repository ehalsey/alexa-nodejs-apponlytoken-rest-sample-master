/*
 * Copyright (c) Microsoft All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

// Application credentials from the Azure Management Portal.
module.exports = {
  clientId: 'eefbd743-d091-45f5-8b93-110320562bdd',
  clientSecret: 'arJYi/aXcBqQKJ68nXhrylkcgjXPg74FrN/SClJX3Rw=',
  tokenEndpoint: 'https://login.windows.net/f8ac75ce-d250-407e-b8cb-e05f5b4cd913/oauth2/token'
};
